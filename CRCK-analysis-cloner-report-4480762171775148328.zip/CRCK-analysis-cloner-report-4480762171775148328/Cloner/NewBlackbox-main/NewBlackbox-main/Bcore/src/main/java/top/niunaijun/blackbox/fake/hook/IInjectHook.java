package top.niunaijun.blackbox.fake.hook;


public interface IInjectHook {
    void injectHook();

    boolean isBadEnv();
}
