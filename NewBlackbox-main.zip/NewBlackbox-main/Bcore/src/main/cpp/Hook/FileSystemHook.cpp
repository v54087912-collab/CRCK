#include "FileSystemHook.h"
#include "Log.h"
#include "xdl.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <cstring>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "IO.h"
#include "Dobby/dobby.h"

// Original function pointers
static int (*orig_open)(const char *pathname, int flags, ...);
static int (*orig_open64)(const char *pathname, int flags, ...);
static int (*orig_openat)(int dirfd, const char *pathname, int flags, ...);
static int (*orig_faccessat)(int dirfd, const char *pathname, int mode, int flags);

// Helper to sanitize /proc/self/maps
int create_fake_maps() {
    // Determine cache directory via cmdline
    char cmdline[256] = {0};
    int fd_cmd = open("/proc/self/cmdline", O_RDONLY);
    if (fd_cmd >= 0) {
        read(fd_cmd, cmdline, sizeof(cmdline) - 1);
        close(fd_cmd);
    } else {
        // Fallback: try using /sdcard/Android/data/pkg if accessible, or just return -1
        return -1;
    }

    std::string pkgName = cmdline;
    // Basic sanitization of pkgName (remove nulls/args)
    if (pkgName.empty()) return -1;

    std::string cachePath = "/data/data/" + pkgName + "/cache/maps_spoofed_XXXXXX";

    char pathBuf[512];
    strncpy(pathBuf, cachePath.c_str(), sizeof(pathBuf));

    int fd = mkstemp(pathBuf);
    if (fd < 0) {
        ALOGE("FileSystemHook: Failed to create temp maps file");
        return -1;
    }

    // Unlink immediately so it's removed on close
    unlink(pathBuf);

    // Use orig_open to avoid recursion
    int src_fd = -1;
    if (orig_open) {
        src_fd = orig_open("/proc/self/maps", O_RDONLY);
    } else if (orig_openat) {
        src_fd = orig_openat(AT_FDCWD, "/proc/self/maps", O_RDONLY);
    }

    if (src_fd >= 0) {
        char buffer[4096];
        std::string content;
        ssize_t bytesRead;
        while ((bytesRead = read(src_fd, buffer, sizeof(buffer))) > 0) {
            content.append(buffer, bytesRead);
        }
        close(src_fd);

        // Process content line by line
        std::istringstream stream(content);
        std::string line;
        std::string finalContent;
        while (std::getline(stream, line)) {
            // Robust path sanitization for Virtual Environments
            // 1. Remove /virtual/ prefix if present
            size_t pos = line.find("/virtual/");
            if (pos != std::string::npos) {
                 line.replace(pos, 9, "/");
            }

            // 2. Handle "split_config" or other suffixes often added by virtual apps
            // This is a common pattern in virtualized environments where base.apk is split
            // e.g., /data/app/com.game/base.apk becomes /data/user/0/com.cloner/.../base.apk

            // 3. Ensure the path looks "native"
            // If the path contains "com.cloner" (host pkg), try to replace with target pkg if known,
            // or just ensure it starts with /data/app/ or /data/data/

            // For now, the simple /virtual/ strip is often enough, but let's add logic to
            // handle lines that might be "hidden" or malformed by the virtualization engine.

            finalContent += line + "\n";
        }
        write(fd, finalContent.c_str(), finalContent.size());
    } else {
        ALOGE("FileSystemHook: Failed to open original /proc/self/maps");
    }
    
    // Rewind for reading
    lseek(fd, 0, SEEK_SET);
    
    return fd;
}

int new_open(const char *pathname, int flags, ...) {
    mode_t mode = 0;
    if ((flags & O_CREAT)) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
    }

    if (pathname) {
        // 1. Check for maps access
        if (strstr(pathname, "/proc/") && strstr(pathname, "/maps")) {
            int fd = create_fake_maps();
            if (fd >= 0) {
                ALOGD("FileSystemHook: Serving fake maps for %s", pathname);
                return fd;
            }
        }

        // 2. Redirect other paths using IO rules
        const char *redirect = IO::redirectPath(pathname);
        if (redirect && strcmp(redirect, pathname) != 0) {
             ALOGD("FileSystemHook: Redirecting %s -> %s", pathname, redirect);
             return orig_open(redirect, flags, mode);
        }
    }
    
    return orig_open(pathname, flags, mode);
}

int new_open64(const char *pathname, int flags, ...) {
    mode_t mode = 0;
    if ((flags & O_CREAT)) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
    }
    
    if (pathname) {
        if (strstr(pathname, "/proc/") && strstr(pathname, "/maps")) {
            int fd = create_fake_maps();
            if (fd >= 0) {
                ALOGD("FileSystemHook: Serving fake maps (64) for %s", pathname);
                return fd;
            }
        }

        const char *redirect = IO::redirectPath(pathname);
        if (redirect && strcmp(redirect, pathname) != 0) {
             return orig_open64(redirect, flags, mode);
        }
    }

    return orig_open64(pathname, flags, mode);
}

int new_openat(int dirfd, const char *pathname, int flags, ...) {
    mode_t mode = 0;
    if ((flags & O_CREAT)) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
    }

    if (pathname) {
        if (strstr(pathname, "/proc/") && strstr(pathname, "/maps")) {
            int fd = create_fake_maps();
            if (fd >= 0) {
                ALOGD("FileSystemHook: Serving fake maps (openat) for %s", pathname);
                return fd;
            }
        }

        const char *redirect = IO::redirectPath(pathname);
        if (redirect && strcmp(redirect, pathname) != 0) {
             return orig_openat(dirfd, redirect, flags, mode);
        }
    }
    return orig_openat(dirfd, pathname, flags, mode);
}

int new_faccessat(int dirfd, const char *pathname, int mode, int flags) {
    if (pathname) {
        const char *redirect = IO::redirectPath(pathname);
        if (redirect && strcmp(redirect, pathname) != 0) {
             return orig_faccessat(dirfd, redirect, mode, flags);
        }
    }
    return orig_faccessat(dirfd, pathname, mode, flags);
}

void FileSystemHook::init() {
    ALOGD("FileSystemHook: Initializing file system hooks with Dobby");
    
    void* handle = xdl_open("libc.so", XDL_DEFAULT);
    if (!handle) {
        ALOGE("FileSystemHook: Failed to open libc.so");
        return;
    }
    
    void* open_sym = xdl_sym(handle, "open", nullptr);
    if (open_sym) {
        DobbyHook(open_sym, (void *)new_open, (void **)&orig_open);
        ALOGD("FileSystemHook: Hooked open");
    }
    
    void* open64_sym = xdl_sym(handle, "open64", nullptr);
    if (open64_sym) {
        DobbyHook(open64_sym, (void *)new_open64, (void **)&orig_open64);
        ALOGD("FileSystemHook: Hooked open64");
    }

    void* openat_sym = xdl_sym(handle, "openat", nullptr);
    if (openat_sym) {
        DobbyHook(openat_sym, (void *)new_openat, (void **)&orig_openat);
        ALOGD("FileSystemHook: Hooked openat");
    }

    void* faccessat_sym = xdl_sym(handle, "faccessat", nullptr);
    if (faccessat_sym) {
        DobbyHook(faccessat_sym, (void *)new_faccessat, (void **)&orig_faccessat);
        ALOGD("FileSystemHook: Hooked faccessat");
    }
    
    xdl_close(handle);
}
