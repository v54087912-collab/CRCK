package top.niunaijun.blackbox.core.system.user;


public enum BUserStatus {
    ENABLE, DISABLE
}
