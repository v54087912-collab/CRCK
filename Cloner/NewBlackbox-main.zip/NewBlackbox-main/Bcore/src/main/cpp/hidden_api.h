
#ifndef BLACKBOX2_HIDDEN_API_H
#define BLACKBOX2_HIDDEN_API_H

#include "jni.h"

bool disable_hidden_api(JNIEnv*);
bool disable_resource_loading();

#endif 
