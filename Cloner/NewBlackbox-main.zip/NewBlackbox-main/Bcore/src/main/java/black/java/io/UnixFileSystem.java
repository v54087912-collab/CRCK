package black.java.io;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("java.io.UnixFileSystem")
public interface UnixFileSystem {
}
